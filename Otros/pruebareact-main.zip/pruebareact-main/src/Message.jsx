export function Message() {
    return <p>What a beautiful day!</p>
}